
import React from 'react';

const About: React.FC = () => {
  const team = [
    {
      name: "MATTEO",
      role: "MOTION & STRATEGY",
      image: "https://i.ibb.co/DPdFp4nL/de492a6f-6b46-4274-a0eb-faac8527d52e.jpg",
    },
    {
      name: "THOMAS",
      role: "IDENTITY & STORYTELLING",
      image: "https://i.ibb.co/DPdFp4nL/de492a6f-6b46-4274-a0eb-faac8527d52e.jpg",
    }
  ];

  return (
    <section id="à-propos" className="py-32 bg-black overflow-hidden border-t border-white/5">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-start">
          <div className="lg:sticky lg:top-32">
            <h2 className="text-3xl md:text-5xl font-black tracking-tighter mb-10 uppercase">LES VISAGES <br/> DERRIÈRE <span className="text-violet-500">VOS RÉSEAUX.</span></h2>
            <div className="space-y-8 text-lg text-white/70 leading-relaxed font-medium border border-violet-500/20 p-8 bg-violet-900/5 rounded-sm">
              <p>
                En Partant de Rien CM est né de la rencontre entre deux expertises indispensables au succès digital. Nous ne nous contentons pas de poster : nous fusionnons l'art de l'image et la puissance du mouvement pour bâtir des identités qui marquent les esprits.
              </p>
            </div>
          </div>
          <div className="flex flex-col">
            <div className="relative aspect-[4/3] mb-8 overflow-hidden rounded-sm bg-zinc-900 group">
              <img 
                src="https://i.ibb.co/DPdFp4nL/de492a6f-6b46-4274-a0eb-faac8527d52e.jpg" 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105"
                alt="L'équipe En Partant De Rien CM"
              />
              <div className="absolute inset-0 border border-white/5 group-hover:border-violet-500/30 transition-colors duration-500"></div>
            </div>
            <div className="flex flex-wrap gap-12">
              {team.map((member, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-px bg-violet-500"></div>
                    <h3 className="text-xl font-black tracking-tighter uppercase">{member.name}</h3>
                  </div>
                  <p className="text-[10px] font-black tracking-widest text-violet-500 uppercase">{member.role}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
